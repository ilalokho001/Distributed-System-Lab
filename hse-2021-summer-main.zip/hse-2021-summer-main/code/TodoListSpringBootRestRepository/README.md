Learned:

- Spring Data Rest automatically hides Id in response.
- 



## Spring Data REST


