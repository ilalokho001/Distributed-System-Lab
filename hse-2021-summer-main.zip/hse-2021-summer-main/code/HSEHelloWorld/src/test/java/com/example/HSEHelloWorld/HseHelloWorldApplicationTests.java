package com.example.HSEHelloWorld;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HseHelloWorldApplicationTests {

	@Test
	void contextLoads() {
	}

}
