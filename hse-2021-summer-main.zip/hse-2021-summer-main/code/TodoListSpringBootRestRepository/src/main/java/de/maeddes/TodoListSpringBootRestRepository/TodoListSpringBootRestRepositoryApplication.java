package de.maeddes.TodoListSpringBootRestRepository;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TodoListSpringBootRestRepositoryApplication {

	public static void main(String[] args) {
		SpringApplication.run(TodoListSpringBootRestRepositoryApplication.class, args);
	}

}
