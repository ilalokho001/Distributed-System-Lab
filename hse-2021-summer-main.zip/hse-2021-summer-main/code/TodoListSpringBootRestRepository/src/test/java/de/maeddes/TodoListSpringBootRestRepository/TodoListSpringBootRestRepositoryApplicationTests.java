package de.maeddes.TodoListSpringBootRestRepository;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TodoListSpringBootRestRepositoryApplicationTests {

	@Test
	void contextLoads() {
	}

}
